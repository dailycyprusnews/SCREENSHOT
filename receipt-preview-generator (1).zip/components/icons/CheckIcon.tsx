
import React from 'react';

const CheckIcon: React.FC = () => {
  return (
    <svg viewBox="0 0 100 100" aria-hidden="true" className="block w-full h-full">
      <circle cx="50" cy="50" r="50" fill="#1EC89C" />
      <path
        d="M28 52 L45 69 L74 36"
        stroke="#FFFFFF"
        strokeWidth="7"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
    </svg>
  );
};

export default CheckIcon;
