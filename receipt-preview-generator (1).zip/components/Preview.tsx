import React, { forwardRef } from 'react';
import { ReceiptData } from '../types';
import CheckIcon from './icons/CheckIcon';

interface PreviewProps {
  data: ReceiptData;
}

const Preview = forwardRef<HTMLDivElement, PreviewProps>(({ data }, ref) => {
  return (
    // The outer div has a fixed width, but the height is now dynamic to fit the content.
    <div
      ref={ref}
      className="w-[600px] mx-auto bg-[#1E1E1E] antialiased text-white overflow-hidden"
      style={{
        fontFamily: `"Segoe UI", Roboto, system-ui, -apple-system, "Helvetica Neue", Arial, sans-serif`,
        WebkitFontSmoothing: 'antialiased',
        MozOsxFontSmoothing: 'grayscale',
        textRendering: 'optimizeLegibility',
      }}
    >
      {/* Header (75px) */}
      <div className="h-[75px] bg-[#0C0C0C] flex items-center pl-[24px]">
        <div className="w-[26px] h-[26px] mr-[15px] flex-none basis-[26px] flex items-center">
          <CheckIcon />
        </div>
        <div className="text-[#F0F0F0] font-normal text-[26px] tracking-[-0.1px]">
          Money sent successfully.
        </div>
      </div>

      {/* Body */}
      <div className="pt-[28px] pb-[28px] px-[26px]">
        <div className="space-y-[28px]">
          <div>
            <div className="text-[#E5E7EB] font-normal text-[24px] leading-[30px] tracking-[-0.05px]">Transaction ID</div>
            <div className="text-[#2dd4bf] font-normal text-[26px] leading-[32px] tracking-[-0.05px] mt-[6px]">{data.transactionId}</div>
          </div>

          <div>
            <div className="text-[#E5E7EB] font-normal text-[24px] leading-[30px] tracking-[-0.05px]">Transaction Date &amp; Time</div>
            <div className="text-[#2dd4bf] font-normal text-[26px] leading-[32px] tracking-[-0.05px] mt-[6px]">{data.dateTime}</div>
          </div>

          <div>
            <div className="text-[#E5E7EB] font-normal text-[24px] leading-[30px] tracking-[-0.05px]">Transaction Amount</div>
            <div className="text-[#2dd4bf] font-normal text-[26px] leading-[32px] tracking-[-0.05px] mt-[6px]">{data.amount}</div>
          </div>

          <div>
            <div className="text-[#E5E7EB] font-normal text-[24px] leading-[30px] tracking-[-0.05px]">From Account Title</div>
            <div className="text-[#2dd4bf] font-normal text-[26px] leading-[32px] tracking-[-0.05px] mt-[6px]">{data.fromAccount}</div>
          </div>

          <div>
            <div className="text-[#E5E7EB] font-normal text-[24px] leading-[30px] tracking-[-0.05px]">Beneficiary Name</div>
            <div className="text-[#2dd4bf] font-normal text-[26px] leading-[32px] tracking-[-0.05px] mt-[6px]">{data.beneficiaryName}</div>
          </div>

          <div>
            <div className="text-[#E5E7EB] font-normal text-[24px] leading-[30px] tracking-[-0.05px]">Beneficiary Account/ IBAN</div>
            <div className="text-[#2dd4bf] font-normal text-[26px] leading-[32px] tracking-[-0.05px] mt-[6px]">{data.beneficiaryAccount}</div>
          </div>

          <div>
            <div className="text-[#E5E7EB] font-normal text-[24px] leading-[30px] tracking-[-0.05px]">Purpose</div>
            <div className="text-[#2dd4bf] font-normal text-[26px] leading-[32px] tracking-[-0.05px] mt-[6px]">{data.purpose}</div>
          </div>

          <div>
            <div className="text-[#E5E7EB] font-normal text-[24px] leading-[30px] tracking-[-0.05px]">Comments</div>
            <div className="text-[#2dd4bf] font-normal text-[26px] leading-[32px] tracking-[-0.05px] mt-[6px]">{data.comments}</div>
          </div>

          <div>
            <div className="text-[#E5E7EB] font-normal text-[24px] leading-[30px] tracking-[-0.05px]">Channel</div>
            <div className="text-[#2dd4bf] font-normal text-[26px] leading-[32px] tracking-[-0.05px] mt-[6px]">{data.channel}</div>
          </div>
        </div>
      </div>
    </div>
  );
});

export default Preview;